using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    public Rigidbody playerRigidbody;
    public float speed = 8f;

    bool isDragging = false;

    void Start()
    {
        playerRigidbody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (isDragging) 
        {
            Vector3 screenPos = Camera.main.WorldToScreenPoint(transform.position);
            Vector2 touchPos = Pointer.current.position.ReadValue();
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(new Vector3(touchPos.x, touchPos.y, screenPos.z));
            worldPos.y = 1.6f;
            transform.position = Vector3.MoveTowards(transform.position, worldPos, speed * Time.deltaTime);
        }
    }

    public void OnMove(InputValue value)
    {
        Vector2 movement = value.Get<Vector2>();

        if (movement != null) 
        {
            Vector3 newVelocity = new Vector3(movement.x * speed, 0f, movement.y * speed);
            playerRigidbody.linearVelocity = newVelocity;
        }
    }

    public void Die() 
    {
        gameObject.SetActive(false);

        GameManager gManager = FindFirstObjectByType<GameManager>();
        gManager.EndGame();
    }

    public void OnTouch(InputAction.CallbackContext context) 
    {
        if (context.performed) isDragging = true;
        else if (context.canceled) isDragging = false;
    }
}
