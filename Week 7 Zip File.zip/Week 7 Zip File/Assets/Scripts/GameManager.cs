using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject gameoverText;
    public TextMeshProUGUI timeText;
    public TextMeshProUGUI recordText;

    float survivalTime;
    bool isGameOver;

    void Start()
    {
        survivalTime = 0f;
        isGameOver = false;
    }

    
    void Update()
    {
        if (!isGameOver)
        {
            survivalTime += Time.deltaTime;
            timeText.text = "Time : " + (int)survivalTime;
        }
        
    }

    public void EndGame() 
    {
        isGameOver = true;
        gameoverText.SetActive(true);

        float bestTime = PlayerPrefs.GetFloat("BestTime");
        if (survivalTime > bestTime) 
        {            
            bestTime = survivalTime;
            PlayerPrefs.SetFloat("BestTime", bestTime);
        }
        recordText.text = "Best Time : " + (int)bestTime;
    }

    public void Restart() 
    {
        SceneManager.LoadScene("GameScene");
    }

    public void Quit() 
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
          // ����� ���ø����̼��� �����մϴ�.
          Application.Quit();
#endif
    }

}
