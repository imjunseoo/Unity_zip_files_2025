using UnityEngine;

public class Bulllet : MonoBehaviour
{
    public float speed = 8f;
    Rigidbody btRigidbody;

    void Start()
    {
        btRigidbody = GetComponent<Rigidbody>();
        btRigidbody.linearVelocity = transform.forward * speed;

        Destroy(gameObject, 3f);
    }

    
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player") 
        {
            PlayerMovement pController = other.GetComponent<PlayerMovement>();

            if (pController != null) 
            {
                pController.Die();
            }
        }
    }
}
